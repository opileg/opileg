import { EvaluationData, QUESTIONS_PREPAREDNESS, QUESTIONS_ORGANIZATION } from './types';

// Generate some dummy data for the analytics to look good initially
export const generateMockData = (): EvaluationData[] => {
  const data: EvaluationData[] = [];
  const now = new Date();
  
  // Generate 20 entries going back 10 weeks
  for (let i = 0; i < 20; i++) {
    const date = new Date(now);
    date.setDate(date.getDate() - (i * 7)); // Weekly data roughly
    
    const isFirstService = Math.random() > 0.5;
    
    const ratings: any = {};
    [...QUESTIONS_PREPAREDNESS, ...QUESTIONS_ORGANIZATION].forEach(q => {
      // Random rating between 3 and 5 mostly
      ratings[q.id] = Math.floor(Math.random() * 3) + 3 as any;
    });

    data.push({
      id: `mock-${i}`,
      date: date.toISOString().split('T')[0],
      serviceType: isFirstService ? '1st' : '2nd',
      userId: 'mock-user-1',
      ratings: ratings,
      remarks: {},
      teachersStatus: Math.random() > 0.1 ? 'Present' : 'Absent',
      attendance: {
        adults: Math.floor(Math.random() * 200) + 300,
        teens: Math.floor(Math.random() * 50) + 50,
        children: Math.floor(Math.random() * 80) + 100,
        visitors: Math.floor(Math.random() * 20) + 5,
        newConverts: Math.floor(Math.random() * 5),
        vehicles: Math.floor(Math.random() * 100) + 50,
      },
      generalComments: "Service went well.",
      recommendation: "N/A",
      elderName: "John Doe",
      submittedAt: date.getTime(),
    });
  }
  return data;
};