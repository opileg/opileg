import { EvaluationData, ServiceAssignment, User } from '../types';
import { generateMockData } from '../constants';

// Keys
const KEYS = {
  USERS: 'citam_users',
  SESSION: 'citam_session',
  EVALUATIONS: 'citam_evaluations',
  ASSIGNMENTS: 'citam_assignments',
  OFFLINE_QUEUE: 'citam_offline_queue'
};

// --- User Auth ---

export const registerUser = (user: Omit<User, 'id'>, password: string): User => {
  const users = getUsers();
  if (users.find(u => u.username === user.username)) {
    throw new Error('Username already exists');
  }
  
  const newUser: User = { ...user, id: crypto.randomUUID() };
  // In a real app, hash password. Here we store simply for demo (mock DB)
  const userRecord = { ...newUser, password }; 
  
  localStorage.setItem(KEYS.USERS, JSON.stringify([...users, userRecord]));
  return newUser;
};

export const loginUser = (username: string, password: string): User => {
  const users = getUsers();
  // Check for built-in admin
  if (username === 'admin' && password === 'admin') {
    return { id: 'admin-1', username: 'admin', name: 'System Admin', role: 'admin' };
  }
  
  const user = users.find(u => u.username === username && (u as any).password === password);
  if (!user) throw new Error('Invalid credentials');
  return user;
};

export const getUsers = (): User[] => {
  const stored = localStorage.getItem(KEYS.USERS);
  return stored ? JSON.parse(stored) : [];
};

// --- Assignments ---

export const getAssignments = (): ServiceAssignment[] => {
  const stored = localStorage.getItem(KEYS.ASSIGNMENTS);
  return stored ? JSON.parse(stored) : [];
};

export const saveAssignment = (assignment: ServiceAssignment) => {
  const all = getAssignments();
  localStorage.setItem(KEYS.ASSIGNMENTS, JSON.stringify([...all, assignment]));
};

export const markAssignmentComplete = (id: string) => {
  const all = getAssignments();
  const updated = all.map(a => a.id === id ? { ...a, isCompleted: true } : a);
  localStorage.setItem(KEYS.ASSIGNMENTS, JSON.stringify(updated));
};

// --- Evaluations & Offline Queue ---

export const getEvaluations = (): EvaluationData[] => {
  const stored = localStorage.getItem(KEYS.EVALUATIONS);
  if (stored) return JSON.parse(stored);
  
  // Initialize with mock data if empty
  const mocks = generateMockData();
  localStorage.setItem(KEYS.EVALUATIONS, JSON.stringify(mocks));
  return mocks;
};

export const saveEvaluation = (data: EvaluationData): boolean => {
  const isOnline = navigator.onLine;
  
  if (isOnline) {
    // Save directly to "Server" (Main storage)
    const all = getEvaluations();
    const updated = [...all, { ...data, synced: true }];
    localStorage.setItem(KEYS.EVALUATIONS, JSON.stringify(updated));
    return true; // Synced immediately
  } else {
    // Save to Offline Queue
    const queue = getOfflineQueue();
    localStorage.setItem(KEYS.OFFLINE_QUEUE, JSON.stringify([...queue, { ...data, synced: false }]));
    return false; // Not synced
  }
};

export const getOfflineQueue = (): EvaluationData[] => {
  const stored = localStorage.getItem(KEYS.OFFLINE_QUEUE);
  return stored ? JSON.parse(stored) : [];
};

export const syncOfflineQueue = (): number => {
  const queue = getOfflineQueue();
  if (queue.length === 0) return 0;

  const mainStorage = getEvaluations();
  const markedSynced = queue.map(item => ({ ...item, synced: true }));
  
  localStorage.setItem(KEYS.EVALUATIONS, JSON.stringify([...mainStorage, ...markedSynced]));
  localStorage.setItem(KEYS.OFFLINE_QUEUE, JSON.stringify([])); // Clear queue
  
  return queue.length;
};