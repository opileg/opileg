
export type ServiceType = '1st' | '2nd';
export type RatingValue = 1 | 2 | 3 | 4 | 5;
export type TeacherStatus = 'Absent' | 'Present' | null;

export interface User {
  id: string;
  username: string;
  name: string;
  role: 'admin' | 'elder' | 'pastor'; // Added pastor based on previous context, though not explicitly asked in this specific prompt, it maintains consistency
  status?: 'pending' | 'active'; 
}

export interface ServiceAssignment {
  id: string;
  date: string;
  serviceType: ServiceType;
  elderId: string;
  elderName: string;
  isCompleted: boolean;
}

export interface EvaluationData {
  id: string;
  date: string; // ISO date string YYYY-MM-DD
  serviceType: ServiceType;
  userId: string; // New: Link to user
  assignmentId?: string; // New: Link to assignment
  
  // A. Church Preparedness
  ratings: {
    [key: string]: RatingValue | null;
  };
  remarks: {
    [key: string]: string;
  };

  // B. Service Organization (Specific non-rating fields)
  teachersStatus: TeacherStatus;

  // C. Attendance
  attendance: {
    adults: number;
    teens: number;
    children: number;
    visitors: number;
    newConverts: number;
    vehicles: number;
  };

  // Footer
  generalComments: string;
  recommendation: string;
  elderName: string;
  submittedAt: number; // timestamp
  synced?: boolean; // New: Offline sync status
}

export type TimeFrame = 'weekly' | 'monthly' | 'quarterly' | 'yearly' | 'custom';

export const QUESTIONS_PREPAREDNESS = [
  { id: 'seating', label: 'Seating arrangement' },
  { id: 'cleanliness_general', label: 'General Cleanliness' },
  { id: 'cleanliness_sanitary', label: 'Sanitary Cleanliness' },
  { id: 'service_program', label: 'Order of service program' },
  { id: 'praise_worship', label: 'Praise and Worship' },
  { id: 'media', label: 'Media' },
  { id: 'moderation', label: 'Moderation' },
  { id: 'word', label: 'Sharing the word' },
  { id: 'time_mgmt_prep', label: 'Time management (Prep)' },
  { id: 'protocol', label: 'Protocol' },
];

export const QUESTIONS_ORGANIZATION = [
  { id: 'teens_church', label: 'Teens Church' },
  { id: 'sunday_school', label: 'Sunday School Orderliness' },
  { id: 'time_mgmt_org', label: 'Time management (Org)' },
];
