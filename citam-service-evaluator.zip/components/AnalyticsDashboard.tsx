
import React, { useMemo, useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, PieChart, Pie, Cell
} from 'recharts';
import { EvaluationData, TimeFrame, QUESTIONS_PREPAREDNESS, QUESTIONS_ORGANIZATION, ServiceType } from '../types';
import { Calendar, TrendingUp, Users, Filter, X } from 'lucide-react';

interface AnalyticsDashboardProps {
  data: EvaluationData[];
}

const COLORS = ['#0ea5e9', '#22c55e', '#eab308', '#f97316', '#ef4444', '#8b5cf6'];

export const AnalyticsDashboard: React.FC<AnalyticsDashboardProps> = ({ data }) => {
  // Filter States
  const [timeFrame, setTimeFrame] = useState<TimeFrame>('monthly');
  const [serviceFilter, setServiceFilter] = useState<'all' | ServiceType>('all');
  
  // Custom Date Range State
  const [customStart, setCustomStart] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() - 1);
    return d.toISOString().split('T')[0];
  });
  const [customEnd, setCustomEnd] = useState(() => new Date().toISOString().split('T')[0]);
  
  const [showFilters, setShowFilters] = useState(false);

  // Filter Data Logic
  const filteredData = useMemo(() => {
    const now = new Date();
    // Normalize time to midnight for accurate date comparison
    now.setHours(0,0,0,0);

    return data.filter(d => {
      // 1. Service Type Filter
      if (serviceFilter !== 'all' && d.serviceType !== serviceFilter) {
        return false;
      }

      // 2. Date Filter
      const entryDate = new Date(d.date);
      entryDate.setHours(0,0,0,0);

      if (timeFrame === 'custom') {
        const start = new Date(customStart);
        const end = new Date(customEnd);
        start.setHours(0,0,0,0);
        end.setHours(23,59,59,999); // Include the end date fully
        return entryDate >= start && entryDate <= end;
      }

      // Standard Timeframes (Calculated from Today backwards)
      const diffTime = Math.abs(now.getTime() - entryDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      if (timeFrame === 'weekly') return diffDays <= 7;
      if (timeFrame === 'monthly') return diffDays <= 30;
      if (timeFrame === 'quarterly') return diffDays <= 90;
      if (timeFrame === 'yearly') return diffDays <= 365;
      
      return true;
    }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [data, timeFrame, customStart, customEnd, serviceFilter]);

  // Aggregate Scores Logic
  const scoreData = useMemo(() => {
    const categoryScores: Record<string, { total: number, count: number }> = {};
    
    // Initialize
    [...QUESTIONS_PREPAREDNESS, ...QUESTIONS_ORGANIZATION].forEach(q => {
      categoryScores[q.label] = { total: 0, count: 0 };
    });

    filteredData.forEach(entry => {
      Object.entries(entry.ratings).forEach(([key, val]) => {
        if (val) {
          const q = [...QUESTIONS_PREPAREDNESS, ...QUESTIONS_ORGANIZATION].find(q => q.id === key);
          if (q) {
            categoryScores[q.label].total += val as number;
            categoryScores[q.label].count += 1;
          }
        }
      });
    });

    return Object.entries(categoryScores)
      .map(([name, stats]) => ({
        name: name.length > 15 ? name.substring(0, 15) + '...' : name,
        score: stats.count > 0 ? parseFloat((stats.total / stats.count).toFixed(1)) : 0
      }))
      .sort((a, b) => b.score - a.score)
      .slice(0, 8); 
  }, [filteredData]);

  // Attendance Trend Logic
  const attendanceTrend = useMemo(() => {
    return filteredData.map(d => ({
      date: new Date(d.date).toLocaleDateString(undefined, { month: 'short', day: 'numeric' }),
      Total: d.attendance.adults + d.attendance.teens + d.attendance.children + d.attendance.visitors
    }));
  }, [filteredData]);

  // Attendance Composition Logic
  const attendanceComposition = useMemo(() => {
    const totals = { Adults: 0, Teens: 0, Children: 0, Visitors: 0 };
    filteredData.forEach(d => {
      totals.Adults += d.attendance.adults;
      totals.Teens += d.attendance.teens;
      totals.Children += d.attendance.children;
      totals.Visitors += d.attendance.visitors;
    });
    return Object.entries(totals).map(([name, value]) => ({ name, value }));
  }, [filteredData]);

  // Stats Cards
  const avgAttendance = useMemo(() => {
    if (filteredData.length === 0) return 0;
    const total = filteredData.reduce((acc, curr) => acc + curr.attendance.adults + curr.attendance.teens + curr.attendance.children, 0);
    return Math.round(total / filteredData.length);
  }, [filteredData]);

  const avgScore = useMemo(() => {
    if (scoreData.length === 0) return 0;
    const total = scoreData.reduce((acc, curr) => acc + curr.score, 0);
    return (total / scoreData.length).toFixed(1);
  }, [scoreData]);

  return (
    <div className="pb-24 animate-fadeIn">
      {/* Filters Header */}
      <div className="bg-white p-4 shadow-sm sticky top-0 z-10 space-y-3">
        <div className="flex justify-between items-center">
          <div>
            <h2 className="font-bold text-lg text-gray-800">Analytics</h2>
            <p className="text-xs text-gray-400">
              {filteredData.length} records found
            </p>
          </div>
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`p-2 rounded-lg text-sm font-medium flex items-center gap-2 transition-colors ${showFilters ? 'bg-brand-50 text-brand-600' : 'bg-gray-100 text-gray-600'}`}
          >
            <Filter size={16} />
            Filters
          </button>
        </div>

        {/* Collapsible Filter Panel */}
        {showFilters && (
          <div className="bg-gray-50 p-3 rounded-lg border border-gray-200 space-y-3 animate-fadeIn">
            
            {/* Time Frame Buttons */}
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase block mb-1">Time Range</label>
              <div className="flex flex-wrap gap-1">
                {(['weekly', 'monthly', 'quarterly', 'yearly', 'custom'] as TimeFrame[]).map((tf) => (
                  <button
                    key={tf}
                    onClick={() => setTimeFrame(tf)}
                    className={`px-3 py-1.5 text-xs font-medium capitalize rounded-md border transition-all 
                      ${timeFrame === tf 
                        ? 'bg-brand-600 text-white border-brand-600 shadow-sm' 
                        : 'bg-white text-gray-600 border-gray-200 hover:bg-gray-100'}`}
                  >
                    {tf}
                  </button>
                ))}
              </div>
            </div>

            {/* Custom Date Inputs */}
            {timeFrame === 'custom' && (
              <div className="grid grid-cols-2 gap-2 bg-white p-2 rounded border border-gray-200">
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase">From</label>
                  <input 
                    type="date" 
                    value={customStart} 
                    onChange={(e) => setCustomStart(e.target.value)}
                    className="w-full text-sm font-medium focus:outline-none"
                  />
                </div>
                <div>
                  <label className="text-[10px] text-gray-400 font-bold uppercase">To</label>
                  <input 
                    type="date" 
                    value={customEnd} 
                    onChange={(e) => setCustomEnd(e.target.value)}
                    className="w-full text-sm font-medium focus:outline-none"
                  />
                </div>
              </div>
            )}

            {/* Service Type Filter */}
            <div>
              <label className="text-xs font-bold text-gray-500 uppercase block mb-1">Service</label>
              <div className="flex gap-1 bg-white border border-gray-200 rounded-md p-1 w-full max-w-[200px]">
                {(['all', '1st', '2nd'] as const).map(type => (
                  <button
                    key={type}
                    onClick={() => setServiceFilter(type)}
                    className={`flex-1 text-xs py-1 rounded transition-colors font-medium capitalize
                      ${serviceFilter === type ? 'bg-brand-100 text-brand-700' : 'text-gray-500 hover:bg-gray-50'}`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>

          </div>
        )}
      </div>

      <div className="p-4 space-y-4">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 text-gray-400 mb-1">
              <Users size={16} />
              <span className="text-xs font-medium uppercase">Avg Attendance</span>
            </div>
            <div className="text-2xl font-bold text-gray-800">{avgAttendance}</div>
          </div>
          <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
            <div className="flex items-center gap-2 text-gray-400 mb-1">
              <TrendingUp size={16} />
              <span className="text-xs font-medium uppercase">Avg Rating</span>
            </div>
            <div className="text-2xl font-bold text-gray-800">{avgScore}<span className="text-sm text-gray-400 font-normal">/5</span></div>
          </div>
        </div>

        {filteredData.length === 0 ? (
          <div className="text-center py-10 bg-gray-100 rounded-xl border border-dashed border-gray-300">
            <p className="text-gray-500 text-sm">No data found for selected filters.</p>
          </div>
        ) : (
          <>
            {/* Attendance Trend Chart */}
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-700 mb-4 text-sm">Attendance Trend</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart data={attendanceTrend}>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                    <XAxis dataKey="date" tick={{fontSize: 10}} tickLine={false} axisLine={false} />
                    <YAxis tick={{fontSize: 10}} tickLine={false} axisLine={false} />
                    <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                    <Line type="monotone" dataKey="Total" stroke="#0ea5e9" strokeWidth={3} dot={{r: 4}} activeDot={{r: 6}} />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Category Performance Chart */}
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-700 mb-4 text-sm">Top Performance Areas</h3>
              <div className="h-64">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={scoreData} layout="vertical" margin={{ left: 20 }}>
                    <CartesianGrid strokeDasharray="3 3" horizontal={true} vertical={false} stroke="#f0f0f0" />
                    <XAxis type="number" domain={[0, 5]} hide />
                    <YAxis dataKey="name" type="category" width={100} tick={{fontSize: 10}} tickLine={false} axisLine={false} />
                    <Tooltip cursor={{fill: 'transparent'}} contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }} />
                    <Bar dataKey="score" fill="#0ea5e9" radius={[0, 4, 4, 0]} barSize={20} />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>

            {/* Composition Pie Chart */}
            <div className="bg-white p-4 rounded-xl shadow-sm border border-gray-100">
              <h3 className="font-semibold text-gray-700 mb-4 text-sm">Attendance Mix</h3>
              <div className="h-64 flex justify-center">
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={attendanceComposition}
                      cx="50%"
                      cy="50%"
                      innerRadius={60}
                      outerRadius={80}
                      paddingAngle={5}
                      dataKey="value"
                    >
                      {attendanceComposition.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip />
                    <Legend iconType="circle" layout="vertical" verticalAlign="middle" align="right" wrapperStyle={{fontSize: '11px'}} />
                  </PieChart>
                </ResponsiveContainer>
              </div>
            </div>
          </>
        )}

      </div>
    </div>
  );
};
