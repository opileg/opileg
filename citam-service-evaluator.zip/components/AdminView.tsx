import React, { useState, useEffect } from 'react';
import { User, ServiceAssignment } from '../types';
import { getUsers, getAssignments, saveAssignment } from '../services/storage';
import { Calendar, User as UserIcon, CheckCircle, Plus } from 'lucide-react';

export const AdminView: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [assignments, setAssignments] = useState<ServiceAssignment[]>([]);
  
  // Form
  const [selectedElderId, setSelectedElderId] = useState('');
  const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
  const [serviceType, setServiceType] = useState<'1st'|'2nd'>('1st');

  useEffect(() => {
    // Only load elders, not admins
    setUsers(getUsers().filter(u => u.role === 'elder'));
    setAssignments(getAssignments());
  }, []);

  const handleAssign = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedElderId) return;

    const elder = users.find(u => u.id === selectedElderId);
    if (!elder) return;

    const newAssignment: ServiceAssignment = {
      id: crypto.randomUUID(),
      date,
      serviceType,
      elderId: elder.id,
      elderName: elder.name,
      isCompleted: false
    };

    saveAssignment(newAssignment);
    setAssignments([...assignments, newAssignment]);
    setSelectedElderId('');
  };

  return (
    <div className="p-4 space-y-6 pb-24">
      <div className="bg-white p-5 rounded-xl shadow-sm border border-gray-100">
        <h2 className="text-lg font-bold text-gray-800 mb-4 flex items-center gap-2">
          <Plus size={20} className="text-brand-600" />
          New Assignment
        </h2>
        <form onSubmit={handleAssign} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1">Select Elder</label>
            <div className="relative">
              <select 
                value={selectedElderId}
                onChange={(e) => setSelectedElderId(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-lg p-3 text-sm appearance-none focus:outline-none focus:border-brand-500"
                required
              >
                <option value="">-- Choose Elder --</option>
                {users.map(u => (
                  <option key={u.id} value={u.id}>{u.name} (@{u.username})</option>
                ))}
              </select>
              <UserIcon size={16} className="absolute right-3 top-3.5 text-gray-400 pointer-events-none" />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
             <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Date</label>
              <input 
                type="date" 
                value={date}
                onChange={e => setDate(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2.5 text-sm"
                required
              />
             </div>
             <div>
              <label className="block text-xs font-semibold text-gray-500 mb-1">Service</label>
              <select 
                value={serviceType}
                onChange={(e: any) => setServiceType(e.target.value)}
                className="w-full bg-gray-50 border border-gray-200 rounded-lg p-2.5 text-sm"
              >
                <option value="1st">1st Service</option>
                <option value="2nd">2nd Service</option>
              </select>
             </div>
          </div>

          <button className="w-full bg-brand-600 text-white font-bold py-3 rounded-lg hover:bg-brand-700 transition-colors">
            Assign Service
          </button>
        </form>
      </div>

      <div>
        <h3 className="text-md font-bold text-gray-700 mb-3 px-1">Current Roster</h3>
        <div className="space-y-3">
          {assignments.length === 0 ? (
            <p className="text-center text-gray-400 text-sm py-8 bg-gray-50 rounded-lg border border-dashed border-gray-200">No assignments yet</p>
          ) : (
            assignments.slice().reverse().map(a => (
              <div key={a.id} className="bg-white p-4 rounded-xl border border-gray-100 shadow-sm flex justify-between items-center">
                <div>
                  <div className="font-bold text-gray-800">{a.elderName}</div>
                  <div className="flex items-center gap-2 text-xs text-gray-500 mt-1">
                    <Calendar size={12} />
                    <span>{a.date}</span>
                    <span className="bg-gray-100 px-1.5 py-0.5 rounded text-gray-600 border border-gray-200">{a.serviceType}</span>
                  </div>
                </div>
                {a.isCompleted ? (
                   <span className="text-green-600 bg-green-50 px-2 py-1 rounded-full text-xs font-medium flex items-center gap-1">
                     <CheckCircle size={12} /> Done
                   </span>
                ) : (
                   <span className="text-amber-600 bg-amber-50 px-2 py-1 rounded-full text-xs font-medium">
                     Pending
                   </span>
                )}
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};