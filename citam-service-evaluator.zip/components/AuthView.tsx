import React, { useState } from 'react';
import { User } from '../types';
import { loginUser, registerUser } from '../services/storage';
import { Lock, User as UserIcon, LogIn, UserPlus } from 'lucide-react';

interface AuthViewProps {
  onLogin: (user: User) => void;
}

export const AuthView: React.FC<AuthViewProps> = ({ onLogin }) => {
  const [isLogin, setIsLogin] = useState(true);
  const [error, setError] = useState('');
  
  // Form State
  const [name, setName] = useState('');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState<'elder' | 'admin'>('elder');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    try {
      if (isLogin) {
        const user = loginUser(username, password);
        onLogin(user);
      } else {
        const newUser = registerUser({ username, name, role }, password);
        onLogin(newUser);
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred');
    }
  };

  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-6 bg-gradient-to-br from-brand-500 to-brand-700">
      <div className="w-full max-w-sm bg-white rounded-2xl shadow-xl overflow-hidden">
        <div className="p-8 pb-0 text-center">
          <div className="w-16 h-16 bg-brand-100 text-brand-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <Lock size={32} />
          </div>
          <h2 className="text-2xl font-bold text-gray-800">{isLogin ? 'Welcome Back' : 'Create Account'}</h2>
          <p className="text-gray-500 text-sm mt-1">{isLogin ? 'Sign in to access evaluations' : 'Register as a Church Elder'}</p>
        </div>

        <form onSubmit={handleSubmit} className="p-8 space-y-4">
          {error && (
            <div className="bg-red-50 text-red-600 text-xs p-3 rounded-lg border border-red-100">
              {error}
            </div>
          )}

          {!isLogin && (
             <div className="space-y-1">
              <label className="text-xs font-semibold text-gray-600">Full Name</label>
              <div className="flex items-center border border-gray-300 rounded-lg bg-gray-50 px-3">
                <UserIcon size={18} className="text-gray-400" />
                <input 
                  type="text" 
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full p-3 bg-transparent text-sm focus:outline-none"
                  placeholder="John Doe"
                />
              </div>
            </div>
          )}

          <div className="space-y-1">
            <label className="text-xs font-semibold text-gray-600">Username</label>
            <div className="flex items-center border border-gray-300 rounded-lg bg-gray-50 px-3">
              <UserIcon size={18} className="text-gray-400" />
              <input 
                type="text" 
                required
                value={username}
                onChange={e => setUsername(e.target.value)}
                className="w-full p-3 bg-transparent text-sm focus:outline-none"
                placeholder="username"
              />
            </div>
          </div>

          <div className="space-y-1">
            <label className="text-xs font-semibold text-gray-600">Password</label>
            <div className="flex items-center border border-gray-300 rounded-lg bg-gray-50 px-3">
              <Lock size={18} className="text-gray-400" />
              <input 
                type="password" 
                required
                value={password}
                onChange={e => setPassword(e.target.value)}
                className="w-full p-3 bg-transparent text-sm focus:outline-none"
                placeholder="••••••••"
              />
            </div>
          </div>
          
          {!isLogin && (
            <div className="space-y-1">
               <label className="text-xs font-semibold text-gray-600">Role</label>
               <div className="flex bg-gray-100 rounded-lg p-1">
                 <button type="button" onClick={() => setRole('elder')} className={`flex-1 py-2 text-xs font-medium rounded ${role === 'elder' ? 'bg-white shadow text-brand-600' : 'text-gray-500'}`}>Elder</button>
                 <button type="button" onClick={() => setRole('admin')} className={`flex-1 py-2 text-xs font-medium rounded ${role === 'admin' ? 'bg-white shadow text-brand-600' : 'text-gray-500'}`}>Admin</button>
               </div>
            </div>
          )}

          <button 
            type="submit" 
            className="w-full py-3 bg-brand-600 hover:bg-brand-700 text-white font-bold rounded-xl shadow-lg transition-transform active:scale-95 flex items-center justify-center gap-2"
          >
            {isLogin ? <LogIn size={18} /> : <UserPlus size={18} />}
            {isLogin ? 'Sign In' : 'Register'}
          </button>
        </form>

        <div className="bg-gray-50 p-4 text-center border-t border-gray-100">
          <p className="text-xs text-gray-500">
            {isLogin ? "Don't have an account?" : "Already have an account?"}
            <button 
              onClick={() => { setIsLogin(!isLogin); setError(''); }}
              className="ml-2 text-brand-600 font-bold hover:underline"
            >
              {isLogin ? 'Register' : 'Login'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};