import React, { useState } from 'react';
import { MessageSquare } from 'lucide-react';

interface RatingRowProps {
  label: string;
  value: number | null;
  remarks: string;
  onChange: (val: number) => void;
  onRemarksChange: (val: string) => void;
}

export const RatingRow: React.FC<RatingRowProps> = ({ 
  label, 
  value, 
  remarks, 
  onChange, 
  onRemarksChange 
}) => {
  const [showRemarks, setShowRemarks] = useState(!!remarks);

  return (
    <div className="mb-6 border-b border-gray-100 pb-4 last:border-0">
      <div className="flex justify-between items-center mb-2">
        <label className="text-sm font-medium text-gray-800">{label}</label>
        <button 
          onClick={() => setShowRemarks(!showRemarks)}
          className={`p-1 rounded-full ${remarks ? 'text-blue-600 bg-blue-50' : 'text-gray-400 hover:text-gray-600'}`}
          type="button"
        >
          <MessageSquare size={16} />
        </button>
      </div>

      <div className="flex justify-between items-center gap-1">
        {[5, 4, 3, 2, 1].map((rating) => (
          <button
            key={rating}
            type="button"
            onClick={() => onChange(rating)}
            className={`
              flex flex-col items-center justify-center w-10 h-10 rounded-lg border transition-all
              ${value === rating 
                ? 'bg-brand-600 border-brand-600 text-white shadow-md transform scale-105' 
                : 'bg-white border-gray-200 text-gray-500 hover:border-brand-200 hover:bg-brand-50'
              }
            `}
          >
            <span className="text-sm font-bold">{rating}</span>
          </button>
        ))}
      </div>
      <div className="flex justify-between px-1 mt-1 text-[10px] text-gray-400">
        <span>V. Good</span>
        <span>Bad</span>
      </div>

      {(showRemarks || remarks) && (
        <input
          type="text"
          value={remarks}
          onChange={(e) => onRemarksChange(e.target.value)}
          placeholder="Add remarks..."
          className="mt-3 w-full text-sm p-2 border border-gray-200 rounded-md focus:ring-2 focus:ring-brand-500 focus:outline-none"
        />
      )}
    </div>
  );
};