import React, { useState, useEffect } from 'react';
import { Save, Calendar, User, Truck, Users } from 'lucide-react';
import { EvaluationData, QUESTIONS_PREPAREDNESS, QUESTIONS_ORGANIZATION, ServiceType, TeacherStatus, ServiceAssignment, User as UserType, RatingValue } from '../types';
import { RatingRow } from './ui/RatingRow';

interface FormViewProps {
  currentUser: UserType;
  assignment?: ServiceAssignment | null; // Optional assignment to fulfill
  onSubmit: (data: EvaluationData) => void;
}

export const FormView: React.FC<FormViewProps> = ({ currentUser, assignment, onSubmit }) => {
  const [date, setDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [serviceType, setServiceType] = useState<ServiceType>('1st');
  
  // Form Fields
  const [ratings, setRatings] = useState<Record<string, RatingValue | null>>({});
  const [remarks, setRemarks] = useState<Record<string, string>>({});
  const [teachersStatus, setTeachersStatus] = useState<TeacherStatus>(null);
  const [attendance, setAttendance] = useState({
    adults: 0, teens: 0, children: 0, visitors: 0, newConverts: 0, vehicles: 0
  });
  const [generalComments, setGeneralComments] = useState('');
  const [recommendation, setRecommendation] = useState('');
  const [elderName, setElderName] = useState(currentUser.name);

  // State initialization from assignment
  useEffect(() => {
    if (assignment) {
      setDate(assignment.date);
      setServiceType(assignment.serviceType);
    }
  }, [assignment]);

  const [activeSection, setActiveSection] = useState<'A' | 'B' | 'C' | 'D'>('A');

  const handleRatingChange = (id: string, val: number) => {
    setRatings(prev => ({ ...prev, [id]: val as RatingValue }));
  };

  const handleRemarkChange = (id: string, val: string) => {
    setRemarks(prev => ({ ...prev, [id]: val }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const data: EvaluationData = {
      id: crypto.randomUUID(),
      date,
      serviceType,
      userId: currentUser.id,
      assignmentId: assignment?.id,
      ratings,
      remarks,
      teachersStatus,
      attendance,
      generalComments,
      recommendation,
      elderName,
      submittedAt: Date.now()
    };
    onSubmit(data);
    
    // Reset minimal state for next entry if not an assignment
    if (!assignment) {
        setRatings({});
        setRemarks({});
        setGeneralComments('');
        setRecommendation('');
        window.scrollTo(0,0);
    }
  };

  const SectionHeader = ({ title, section, icon: Icon }: { title: string, section: string, icon: any }) => (
    <div 
      onClick={() => setActiveSection(section as any)}
      className={`flex items-center gap-2 p-4 font-bold text-lg cursor-pointer transition-colors ${activeSection === section ? 'bg-brand-50 text-brand-700 border-l-4 border-brand-600' : 'bg-white text-gray-600 border-l-4 border-transparent'}`}
    >
      <Icon size={20} />
      <span>{title}</span>
    </div>
  );

  return (
    <form onSubmit={handleSubmit} className="pb-24">
      {/* Assignment Banner */}
      {assignment && (
        <div className="bg-amber-50 border-b border-amber-200 p-3 text-sm text-amber-800 flex items-center justify-between">
           <span className="font-semibold">Fulfilling Assignment</span>
           <span className="text-xs bg-amber-200 px-2 py-0.5 rounded-full text-amber-900">{assignment.date}</span>
        </div>
      )}

      {/* Meta Data Card */}
      <div className="bg-white p-4 mb-2 shadow-sm">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1">DATE</label>
            <input 
              type="date" 
              required
              disabled={!!assignment}
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className={`w-full bg-gray-50 border border-gray-200 rounded p-2 text-sm ${assignment ? 'opacity-60 cursor-not-allowed' : ''}`}
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-gray-500 mb-1">SERVICE</label>
            <div className="flex bg-gray-50 rounded p-1 border border-gray-200">
              <button
                type="button"
                disabled={!!assignment}
                onClick={() => setServiceType('1st')}
                className={`flex-1 text-sm py-1.5 rounded transition-colors ${serviceType === '1st' ? 'bg-white shadow-sm font-medium text-brand-600' : 'text-gray-500'} ${assignment ? 'cursor-not-allowed' : ''}`}
              >
                1st
              </button>
              <button
                type="button"
                disabled={!!assignment}
                onClick={() => setServiceType('2nd')}
                className={`flex-1 text-sm py-1.5 rounded transition-colors ${serviceType === '2nd' ? 'bg-white shadow-sm font-medium text-brand-600' : 'text-gray-500'} ${assignment ? 'cursor-not-allowed' : ''}`}
              >
                2nd
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Accordion Sections */}
      <div className="space-y-2">
        
        {/* Section A */}
        <div className="bg-white shadow-sm">
          <SectionHeader title="A. Church Preparedness" section="A" icon={Calendar} />
          {activeSection === 'A' && (
            <div className="p-4 animate-fadeIn">
              {QUESTIONS_PREPAREDNESS.map((q) => (
                <RatingRow
                  key={q.id}
                  label={q.label}
                  value={ratings[q.id] || null}
                  remarks={remarks[q.id] || ''}
                  onChange={(val) => handleRatingChange(q.id, val)}
                  onRemarksChange={(val) => handleRemarkChange(q.id, val)}
                />
              ))}
              <button 
                type="button" 
                onClick={() => setActiveSection('B')}
                className="w-full mt-4 py-3 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200"
              >
                Next Section
              </button>
            </div>
          )}
        </div>

        {/* Section B */}
        <div className="bg-white shadow-sm">
          <SectionHeader title="B. Service Organization" section="B" icon={Users} />
          {activeSection === 'B' && (
            <div className="p-4 animate-fadeIn">
              {QUESTIONS_ORGANIZATION.map((q) => (
                <RatingRow
                  key={q.id}
                  label={q.label}
                  value={ratings[q.id] || null}
                  remarks={remarks[q.id] || ''}
                  onChange={(val) => handleRatingChange(q.id, val)}
                  onRemarksChange={(val) => handleRemarkChange(q.id, val)}
                />
              ))}
              
              <div className="mb-6 pt-4 border-t border-gray-100">
                <label className="text-sm font-medium text-gray-800 mb-2 block">Teachers</label>
                <div className="flex gap-4">
                  <label className={`flex-1 border rounded-lg p-3 flex items-center justify-center cursor-pointer ${teachersStatus === 'Absent' ? 'bg-red-50 border-red-500 text-red-700' : 'bg-white border-gray-200'}`}>
                    <input type="radio" name="teachers" className="hidden" onClick={() => setTeachersStatus('Absent')} />
                    <span className="font-medium">Absent</span>
                  </label>
                  <label className={`flex-1 border rounded-lg p-3 flex items-center justify-center cursor-pointer ${teachersStatus === 'Present' ? 'bg-green-50 border-green-500 text-green-700' : 'bg-white border-gray-200'}`}>
                    <input type="radio" name="teachers" className="hidden" onClick={() => setTeachersStatus('Present')} />
                    <span className="font-medium">Present</span>
                  </label>
                </div>
              </div>

              <button 
                type="button" 
                onClick={() => setActiveSection('C')}
                className="w-full mt-4 py-3 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200"
              >
                Next Section
              </button>
            </div>
          )}
        </div>

        {/* Section C */}
        <div className="bg-white shadow-sm">
          <SectionHeader title="C. Attendance" section="C" icon={User} />
          {activeSection === 'C' && (
            <div className="p-4 animate-fadeIn">
              <div className="grid grid-cols-2 gap-4">
                {Object.keys(attendance).map((key) => (
                  <div key={key} className="bg-gray-50 p-3 rounded-lg border border-gray-200">
                    <label className="block text-xs font-bold text-gray-400 uppercase mb-1">
                      {key.replace(/([A-Z])/g, ' $1').trim()}
                    </label>
                    <input
                      type="number"
                      min="0"
                      className="w-full text-2xl font-bold bg-transparent focus:outline-none text-gray-800"
                      value={(attendance as any)[key]}
                      onChange={(e) => setAttendance(prev => ({ ...prev, [key]: parseInt(e.target.value) || 0 }))}
                      onFocus={(e) => e.target.select()}
                    />
                  </div>
                ))}
              </div>
               <button 
                type="button" 
                onClick={() => setActiveSection('D')}
                className="w-full mt-6 py-3 bg-gray-100 text-gray-700 font-medium rounded-lg hover:bg-gray-200"
              >
                Final Comments
              </button>
            </div>
          )}
        </div>

        {/* Section D - Final */}
        <div className="bg-white shadow-sm">
          <SectionHeader title="D. Remarks & Sign Off" section="D" icon={Save} />
          {activeSection === 'D' && (
            <div className="p-4 animate-fadeIn">
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">General Comments</label>
                  <textarea 
                    className="w-full border border-gray-300 rounded-lg p-3 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none"
                    rows={3}
                    value={generalComments}
                    onChange={(e) => setGeneralComments(e.target.value)}
                    placeholder="Enter overall feedback..."
                  ></textarea>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Recommendation</label>
                  <textarea 
                    className="w-full border border-gray-300 rounded-lg p-3 text-sm focus:ring-2 focus:ring-brand-500 focus:outline-none"
                    rows={2}
                    value={recommendation}
                    onChange={(e) => setRecommendation(e.target.value)}
                    placeholder="Specific recommendations..."
                  ></textarea>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Elder on Duty</label>
                  <div className="flex items-center bg-gray-50 border border-gray-300 rounded-lg px-3">
                    <User size={18} className="text-gray-400" />
                    <input 
                      type="text"
                      className="w-full bg-transparent p-3 text-sm focus:outline-none"
                      placeholder="Name"
                      required
                      value={elderName}
                      onChange={(e) => setElderName(e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="flex items-center gap-2 mt-2">
                  <input type="checkbox" id="sign" required className="w-4 h-4 text-brand-600 rounded" />
                  <label htmlFor="sign" className="text-sm text-gray-600">I certify the above information is accurate (Digital Signature)</label>
                </div>

                <button 
                  type="submit" 
                  className="w-full mt-6 py-4 bg-brand-600 text-white font-bold text-lg rounded-xl shadow-lg hover:bg-brand-700 active:transform active:scale-95 transition-all flex justify-center items-center gap-2"
                >
                  <Save size={20} />
                  Submit Evaluation
                </button>
              </div>
            </div>
          )}
        </div>

      </div>
    </form>
  );
};