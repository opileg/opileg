import React, { useState, useEffect } from 'react';
import { FormView } from './components/FormView';
import { AnalyticsDashboard } from './components/AnalyticsDashboard';
import { AuthView } from './components/AuthView';
import { AdminView } from './components/AdminView';
import { EvaluationData, User, ServiceAssignment } from './types';
import { saveEvaluation, getEvaluations, syncOfflineQueue, getAssignments, markAssignmentComplete, getOfflineQueue } from './services/storage';
import { ClipboardList, BarChart3, User as UserIcon, LogOut, WifiOff, RefreshCw, Calendar, CheckCircle } from 'lucide-react';

type Tab = 'home' | 'form' | 'analytics' | 'admin' | 'profile';

const App: React.FC = () => {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [data, setData] = useState<EvaluationData[]>([]);
  const [assignments, setAssignments] = useState<ServiceAssignment[]>([]);
  
  // Offline State
  const [isOnline, setIsOnline] = useState(navigator.onLine);
  const [isSyncing, setIsSyncing] = useState(false);
  const [syncComplete, setSyncComplete] = useState(false);
  const [showToast, setShowToast] = useState(false);
  
  // Selection
  const [selectedAssignment, setSelectedAssignment] = useState<ServiceAssignment | null>(null);

  // Load User Session
  useEffect(() => {
    const session = localStorage.getItem('citam_session');
    if (session) {
      setUser(JSON.parse(session));
    }
    setData(getEvaluations());
  }, []);

  // Monitor Network & Assignments
  useEffect(() => {
    const handleOnline = () => {
      setIsOnline(true);
      performSync();
    };
    const handleOffline = () => setIsOnline(false);

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);

    // Initial load
    if (user) refreshData();

    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, [user]);

  const performSync = () => {
    setIsSyncing(true);
    setTimeout(() => {
       const syncedCount = syncOfflineQueue();
       if (syncedCount > 0) {
         refreshData();
         setSyncComplete(true);
         setTimeout(() => setSyncComplete(false), 3000);
       }
       setIsSyncing(false);
    }, 1500); // Fake delay for UX
  };

  const refreshData = () => {
    setData(getEvaluations());
    if (user && user.role === 'elder') {
      const allAssignments = getAssignments();
      setAssignments(allAssignments.filter(a => a.elderId === user.id && !a.isCompleted));
    }
  };

  const handleLogin = (u: User) => {
    setUser(u);
    localStorage.setItem('citam_session', JSON.stringify(u));
    setActiveTab(u.role === 'admin' ? 'admin' : 'home');
  };

  const handleLogout = () => {
    setUser(null);
    localStorage.removeItem('citam_session');
    setActiveTab('home');
  };

  const handleFormSubmit = (newEntry: EvaluationData) => {
    const savedImmediately = saveEvaluation(newEntry);
    
    // Mark assignment complete if applicable
    if (newEntry.assignmentId) {
      markAssignmentComplete(newEntry.assignmentId);
      setSelectedAssignment(null);
    }

    refreshData();
    
    // UI Feedback
    setShowToast(true);
    setTimeout(() => setShowToast(false), 3000);
    
    if (savedImmediately) {
      setActiveTab('analytics');
    } else {
      setActiveTab('home'); // Back to home if offline
    }
  };

  const startEvaluation = (assignment?: ServiceAssignment) => {
    if (assignment) setSelectedAssignment(assignment);
    else setSelectedAssignment(null);
    setActiveTab('form');
  };

  if (!user) {
    return <AuthView onLogin={handleLogin} />;
  }

  // --- Render Elder Home ---
  const renderElderHome = () => (
    <div className="p-4 space-y-4">
      <div className="bg-brand-600 text-white p-6 rounded-2xl shadow-lg relative overflow-hidden">
        <div className="relative z-10">
          <h2 className="text-xl font-bold">Welcome, {user.name}</h2>
          <p className="opacity-90 text-sm">You have {assignments.length} upcoming services.</p>
          <button 
            onClick={() => startEvaluation()}
            className="mt-4 bg-white text-brand-600 px-4 py-2 rounded-lg text-sm font-bold shadow-sm active:scale-95 transition-transform"
          >
            New Ad-hoc Evaluation
          </button>
        </div>
        {/* Decorative background element */}
        <div className="absolute top-0 right-0 w-32 h-32 bg-white opacity-10 rounded-full -mr-10 -mt-10"></div>
      </div>

      <h3 className="font-bold text-gray-700 text-lg px-1">My Schedule</h3>
      <div className="space-y-3 pb-20">
        {assignments.length === 0 ? (
          <div className="text-center py-10 bg-white rounded-xl border border-gray-100">
            <Calendar className="mx-auto text-gray-300 mb-2" size={32} />
            <p className="text-gray-400">No pending assignments</p>
          </div>
        ) : (
          assignments.map(a => (
            <div key={a.id} className="bg-white p-4 rounded-xl shadow-sm border border-gray-100 flex justify-between items-center">
              <div>
                <div className="font-bold text-gray-800">{a.date}</div>
                <div className="text-xs text-brand-600 font-medium bg-brand-50 px-2 py-0.5 rounded-full inline-block mt-1">{a.serviceType} Service</div>
              </div>
              <button 
                onClick={() => startEvaluation(a)}
                className="bg-brand-50 text-brand-600 border border-brand-100 px-4 py-2 rounded-lg text-sm font-semibold hover:bg-brand-100"
              >
                Evaluate
              </button>
            </div>
          ))
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col font-sans max-w-md mx-auto shadow-2xl overflow-hidden relative border-x border-gray-100">
      
      {/* Header */}
      <header className="bg-white px-4 py-3 flex justify-between items-center shadow-sm sticky top-0 z-20">
        <div className="flex items-center gap-3">
          {/* Logo */}
          <div className="w-10 h-10 flex items-center justify-center">
             <img 
               src="https://citam.org/wp-content/uploads/2020/09/CITAM-Logo-1.png" 
               alt="CITAM" 
               className="max-w-full max-h-full object-contain"
               onError={(e) => {
                 (e.target as HTMLImageElement).style.display = 'none';
                 (e.target as HTMLImageElement).parentElement!.innerText = '✝️'; // Fallback
               }}
             />
          </div>
          <div>
            <h1 className="text-sm font-bold text-brand-900 tracking-tight leading-none">CITAM Nakuru</h1>
            <span className="text-[10px] text-gray-400 font-medium bg-gray-100 px-1 rounded">{user.role.toUpperCase()}</span>
          </div>
        </div>
        
        {/* Connection Status & Sync Indicator */}
        <div className="flex items-center gap-2">
            {!isOnline && (
              <div className="flex items-center gap-1 bg-red-100 text-red-600 px-2 py-1 rounded-full text-[10px] font-bold transition-all">
                <WifiOff size={12} /> Offline
              </div>
            )}
            
            {isOnline && isSyncing && (
              <div className="flex items-center gap-1 bg-blue-100 text-blue-600 px-2 py-1 rounded-full text-[10px] font-bold animate-pulse">
                <RefreshCw size={12} className="animate-spin" /> Syncing
              </div>
            )}

            {isOnline && syncComplete && !isSyncing && (
                 <div className="flex items-center gap-1 bg-green-100 text-green-600 px-2 py-1 rounded-full text-[10px] font-bold transition-all animate-bounce">
                <CheckCircle size={12} /> Synced
                </div>
            )}
        </div>
      </header>

      {/* Content Area */}
      <main className="flex-1 overflow-y-auto no-scrollbar relative">
        {/* Offline Banner in Content */}
        {!isOnline && (
           <div className="bg-gray-800 text-white text-xs py-1 text-center">
             You are offline. Evaluations will be saved locally.
           </div>
        )}

        {activeTab === 'home' && renderElderHome()}
        {activeTab === 'admin' && <AdminView />}
        {activeTab === 'form' && <FormView currentUser={user} assignment={selectedAssignment} onSubmit={handleFormSubmit} />}
        {activeTab === 'analytics' && <AnalyticsDashboard data={data} />}
        
        {activeTab === 'profile' && (
           <div className="p-4">
             <div className="bg-white p-6 rounded-xl shadow-sm border border-gray-100 text-center">
                <div className="w-20 h-20 bg-gray-100 rounded-full mx-auto mb-4 flex items-center justify-center">
                  <UserIcon size={40} className="text-gray-400" />
                </div>
                <h2 className="text-xl font-bold">{user.name}</h2>
                <p className="text-gray-500 text-sm">@{user.username}</p>
                <div className="mt-6 border-t pt-6">
                   <button onClick={handleLogout} className="w-full flex items-center justify-center gap-2 text-red-600 font-medium py-2 hover:bg-red-50 rounded-lg transition-colors">
                     <LogOut size={18} /> Sign Out
                   </button>
                </div>
             </div>
             
             {/* Debug Info for Offline Queue */}
             <div className="mt-8">
               <h4 className="text-xs font-bold text-gray-400 uppercase mb-2">Device Storage Status</h4>
               <div className="bg-gray-100 p-3 rounded text-xs text-gray-600">
                  <p>Pending Uploads: {getOfflineQueue().length}</p>
                  <p>Total Records: {data.length}</p>
               </div>
             </div>
           </div>
        )}
      </main>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-200 sticky bottom-0 z-20 flex justify-around items-center h-16 safe-area-bottom">
        {user.role === 'elder' && (
          <button 
            onClick={() => setActiveTab('home')}
            className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${activeTab === 'home' ? 'text-brand-600' : 'text-gray-400'}`}
          >
            <div className={`p-1 rounded-full transition-all ${activeTab === 'home' ? 'bg-brand-50 transform scale-110' : ''}`}>
               <ClipboardList size={22} strokeWidth={activeTab === 'home' ? 2.5 : 2} />
            </div>
            <span className="text-[10px] font-medium">Home</span>
          </button>
        )}

        {user.role === 'admin' && (
          <button 
            onClick={() => setActiveTab('admin')}
            className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${activeTab === 'admin' ? 'text-brand-600' : 'text-gray-400'}`}
          >
            <div className={`p-1 rounded-full transition-all ${activeTab === 'admin' ? 'bg-brand-50 transform scale-110' : ''}`}>
               <UserIcon size={22} strokeWidth={activeTab === 'admin' ? 2.5 : 2} />
            </div>
            <span className="text-[10px] font-medium">Roster</span>
          </button>
        )}
        
        <button 
          onClick={() => setActiveTab('analytics')}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${activeTab === 'analytics' ? 'text-brand-600' : 'text-gray-400'}`}
        >
          <div className={`p-1 rounded-full transition-all ${activeTab === 'analytics' ? 'bg-brand-50 transform scale-110' : ''}`}>
             <BarChart3 size={22} strokeWidth={activeTab === 'analytics' ? 2.5 : 2} />
          </div>
          <span className="text-[10px] font-medium">Analytics</span>
        </button>

        <button 
          onClick={() => setActiveTab('profile')}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 ${activeTab === 'profile' ? 'text-brand-600' : 'text-gray-400'}`}
        >
          <div className={`p-1 rounded-full transition-all ${activeTab === 'profile' ? 'bg-brand-50 transform scale-110' : ''}`}>
             <UserIcon size={22} strokeWidth={activeTab === 'profile' ? 2.5 : 2} />
          </div>
          <span className="text-[10px] font-medium">Profile</span>
        </button>
      </nav>

      {/* Toast Notification */}
      {showToast && (
        <div className="absolute top-20 left-1/2 transform -translate-x-1/2 bg-gray-900 text-white px-6 py-3 rounded-full shadow-xl flex items-center gap-2 animate-bounce z-50 whitespace-nowrap">
          <div className="w-2 h-2 bg-green-500 rounded-full"></div>
          <span className="text-sm font-medium">{isOnline ? 'Evaluation Saved!' : 'Saved to Offline Queue'}</span>
        </div>
      )}
    </div>
  );
};

export default App;